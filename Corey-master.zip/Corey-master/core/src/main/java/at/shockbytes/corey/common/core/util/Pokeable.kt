package at.shockbytes.corey.common.core.util

/**
 * Author:  Martin Macheiner
 * Date:    19.03.2018
 */
interface Pokeable {

    fun poke()
}
