package at.shockbytes.corey.common.core.location

data class CoreyLocation(
    val lat: Double,
    val lng: Double,
    val time: Long
)