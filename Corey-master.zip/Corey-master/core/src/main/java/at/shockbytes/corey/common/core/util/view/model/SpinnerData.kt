package at.shockbytes.corey.common.core.util.view.model

/**
 * @author Martin Macheiner
 * Date: 24.02.2017.
 */

data class SpinnerData(var text: String, var iconId: Int)
