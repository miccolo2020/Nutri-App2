package at.shockbytes.corey.common.core.util

/**
 * Author: Martin Macheiner
 * Date: 05.03.2018
 */
data class WatchInfo(val name: String?, val isConnected: Boolean)