package at.shockbytes.corey.common.core

interface Sortable