package at.shockbytes.corey.common.core.util

interface FindClosestDiffable {

    val diffValue: Double
}