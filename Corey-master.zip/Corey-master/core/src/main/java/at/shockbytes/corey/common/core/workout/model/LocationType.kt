package at.shockbytes.corey.common.core.workout.model

enum class LocationType {
    NONE,
    INDOOR,
    OUTDOOR
}