package at.shockbytes.corey.storage

object StorageConstants {

    const val KEY_HIDE_FINISHED_GOALS = "hide_finished_goals"
}