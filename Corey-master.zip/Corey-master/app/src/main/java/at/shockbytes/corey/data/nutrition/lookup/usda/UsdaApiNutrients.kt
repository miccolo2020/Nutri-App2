package at.shockbytes.corey.data.nutrition.lookup.usda

enum class UsdaApiNutrients(val code: Int) {
    ENERGY(code = 208)
}