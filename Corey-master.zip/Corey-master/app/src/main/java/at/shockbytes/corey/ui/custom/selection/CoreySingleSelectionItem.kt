package at.shockbytes.corey.ui.custom.selection

data class CoreySingleSelectionItem(
    val title: String,
    val position: Int,
    val tag: String // Additional data field
)