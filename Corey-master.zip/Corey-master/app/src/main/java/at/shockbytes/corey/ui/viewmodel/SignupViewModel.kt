package at.shockbytes.corey.ui.viewmodel

import at.shockbytes.core.viewmodel.BaseViewModel
import javax.inject.Inject

class SignupViewModel @Inject constructor() : BaseViewModel()