package at.shockbytes.corey.util

import android.graphics.Color

object ShockColors {

    val ERROR = Color.parseColor("#F44336")
}