package at.shockbytes.corey.data.reminder

data class Minutes(val minutes: Long)